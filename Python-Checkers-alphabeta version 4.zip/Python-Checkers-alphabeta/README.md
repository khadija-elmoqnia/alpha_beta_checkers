# Python-Checkers-AI
A checkers AI using the minimax algorithm.
