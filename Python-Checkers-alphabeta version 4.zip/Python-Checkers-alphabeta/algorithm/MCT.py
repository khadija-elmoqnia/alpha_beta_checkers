import random
import math
from copy import deepcopy
from checkers.constants import WIDTH, HEIGHT, SQUARE_SIZE, BLACK, WHITE
from checkers.board import Board
class Node:
    def __init__(self, board, parent=None):
        self.board = board.clone()
        self.parent = parent
        self.children = []
        self.visits = 0
        self.wins = 0

def uct_value(node):
    if node.visits == 0:
        return float('inf')
    return (node.wins / node.visits) + math.sqrt(2 * math.log(node.parent.visits) / node.visits)

def select(node,game):
    while node.children:
        # Choose the child with the highest UCT value for exploration
        node = max(node.children, key=uct_value)
        # Simulate the move for the selected child
        new_node = simulate_child(node,game)
        # If the selected child has not been fully simulated, return it
        if not new_node.visits:
            return new_node
    return node
def simulate_child(node, game):
    if node.children:
        child = random.choice(node.children)
        valid_moves = get_all_moves_mct(child, game)
        
        if valid_moves:
            move = random.choice(valid_moves)
            new_board = simulate_move_mct(child, move)
            new_node = Node(new_board, parent=node)
            return new_node
        else:
            # If there are no valid moves, return the current node
            return node
    else:
        # If there are no children, return the current node
        return node






def expand(node,game):
    moves = get_all_moves_mct(node,game)
    for move in moves:
        new_board = simulate_move_mct(node, move)
        new_node = Node(new_board, parent=node)
        node.children.append(new_node)

    if node.children:
       return random.choice(node.children)
       print(random.choice(node.children))
    else:
    # Handle the case where node.children is empty
        return node  # You might want to return the current node or another appropriate value

def simulate_move_mct(node, move):
    piece, move_coords, skip = move
    new_board = deepcopy(node.board)
    new_board.mcts_move(piece, *move_coords)  # Correct the order of arguments
    if skip:
        new_board.remove(skip)
    return new_board

def backpropagate(node, result):
    while node is not None:
        node.visits += 1
        node.wins += result
        node = node.parent

def mcts_move_ai(initial_board, iterations, color, game):
    root_node = Node(initial_board)

    for _ in range(iterations):
        node = select(root_node,game)
        new_node = expand(node, game)
        result = evaluate(new_node.board)
        backpropagate(new_node, result)

    best_child = max(root_node.children, key=lambda x: x.visits)
    best_move = best_child.board.get_last_applied_move()

    if best_move is not None:
        initial_row, initial_col, final_row, final_col = best_move
        piece = best_child.board.get_piece(initial_row, initial_col)  # Use best_child.board instead of initial_board

        if piece != 0:
           new_board = initial_board.clone()
           new_board.move(piece, final_row, final_col)
           return new_board
        else:
        # Handle the case where piece is 0
        # You might want to log a message or take appropriate action.
           pass
    else:
    # Handle the case where best_move is None
    # You might want to log a message or take appropriate action.
       pass
    return initial_board



def evaluate(board):
    # Add your evaluation logic here based on the current state of the board
    # Return a numeric value representing the evaluation of the board
    return board.evaluate()

def get_all_moves_mct(node, game):
    moves = []

    for piece in node.board.get_all_pieces(WHITE):
        valid_moves = node.board.get_valid_moves(piece)
        for move, skip in valid_moves.items():
            moves.append((piece, move, skip))
    
    return moves

