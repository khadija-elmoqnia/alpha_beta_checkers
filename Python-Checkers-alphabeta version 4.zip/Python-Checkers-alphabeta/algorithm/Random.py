from copy import copy
from copy import deepcopy
import random
from checkers.constants import WHITE

BLACK = (255,0,0)
WHITE = (255, 255, 255)
minimax_nodes_evaluated = 0
alphabeta_nodes_evaluated = 0



def get_random_move(board,game):
    if board.winner() is not None:
        return board  # Return the board if there's already a winner
    white_pieces = board.get_all_pieces(WHITE)
    valid_moves = {}
    new_board= board

    if white_pieces:
        while not valid_moves:  # Keep trying until a valid move is found
            for piece in white_pieces:
                moves = game.get_board().get_valid_moves(piece)
                if moves:
                    valid_moves.update({piece: move for move in moves})
                   
    # If the loop exits, a valid move is found
        selected_piece = random.choice(list(valid_moves.keys()))

        valid_moves = board.get_valid_moves(selected_piece)
        print(valid_moves)
        for move, skip in valid_moves.items(): 
            temp_board = deepcopy(board)
            temp_piece = temp_board.get_piece(selected_piece.row, selected_piece.col)
            new_board = make_move(temp_piece, move, temp_board, game, skip)
        return new_board
    return new_board

def make_move(piece, move, board, game, skip):
    board.move(piece, move[0], move[1])
    if skip:
        board.remove(skip)
    return board