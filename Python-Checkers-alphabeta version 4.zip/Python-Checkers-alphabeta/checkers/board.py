import pygame
from .constants import BLACK, ROWS, SQUARE_SIZE, COLS, WHITE,light_square, dark_square
from .piece import Piece
from copy import deepcopy,copy
class Board:
    def __init__(self):
        self.board = []
        self.BLACK_left = self.white_left = 12
        self.BLACK_kings = self.white_kings = 0
        self.last_move = None
        self.create_board()
    
    def draw_squares(self, win):
        win.fill(dark_square)
        for row in range(ROWS):
            for col in range(row % 2, COLS, 2):
                pygame.draw.rect(win, light_square, (row*SQUARE_SIZE, col *SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))

    def evaluate(self):
        return self.white_left - self.BLACK_left + (self.white_kings * 0.5 - self.BLACK_kings * 0.5)

    def get_all_pieces(self, color):
        pieces = []
        for row in self.board:
            for piece in row:
                if piece != 0 and piece.color == color:
                    pieces.append(piece)
        return pieces

    def move(self, piece, row, col):
        initial_row, initial_col = piece.row, piece.col
    
        self.board[piece.row][piece.col], self.board[row][col] = self.board[row][col], self.board[piece.row][piece.col]
        piece.move(row, col)
        self.last_move = (initial_row, initial_col, row, col)
        if row == ROWS - 1 or row == 0:
            if not piece.is_king():  # Only make king if the piece is not already a king
               piece.make_king()
               if piece.color == WHITE:
                   self.white_kings += 1
               else:
                   self.BLACK_kings += 1


    def get_piece(self, row, col):
        return self.board[row][col]

    def create_board(self):
        for row in range(ROWS):
            self.board.append([])
            for col in range(COLS):
                if col % 2 == ((row +  1) % 2):
                    if row < 3:
                        self.board[row].append(Piece(row, col, WHITE))
                    elif row > 4:
                        self.board[row].append(Piece(row, col, BLACK))
                    else:
                        self.board[row].append(0)
                else:
                    self.board[row].append(0)
        
    def draw(self, win):
        self.draw_squares(win)
        for row in range(ROWS):
            for col in range(COLS):
                piece = self.board[row][col]
                if piece != 0:
                    piece.draw(win)

    def remove(self, pieces):
        for piece in pieces:
            self.board[piece.row][piece.col] = 0
            if piece != 0:
                if piece.is_king():
                    if piece.color == BLACK:
                       self.BLACK_kings -= 1
                    else:
                       self.white_kings -= 1
                if piece.color == BLACK:
                    self.BLACK_left -= 1
                else:
                    self.white_left -= 1
    
    def winner(self):
        
    # Condition 1 : Victoire par élimination    
        if len(self.get_all_pieces(BLACK)) == 0 and self.BLACK_kings == 0:
            print("Condition 1 : Victoire par élimination")
            return WHITE
        elif len(self.get_all_pieces(WHITE)) == 0 and self.white_kings == 0:
            print("Condition 1 : Victoire par élimination")
            return BLACK
        
    # Condition 2 : Victoire par blocage
        if not self.can_move(BLACK) and self.BLACK_left > 0:
            print("Condition 2 : Victoire par blocage")
            return WHITE
        if not self.can_move(WHITE) and self.white_left > 0:
            print("Condition 2 : Victoire par blocage")
            return BLACK

    #Condition 5 : Victoire par règle de trois rois contre un roi
        if self.BLACK_kings == 3 and self.white_kings == 1 and self.white_left == 0:
           print("Condition 5 : Victoire par règle de trois rois contre un roi")
           return BLACK
        elif self.white_kings == 3 and self.BLACK_kings == 1 and self.BLACK_left == 0 :
           print("Condition 5 : Victoire par règle de trois rois contre un roi")
           return WHITE
    # Aucune condition de fin de jeu n'est satisfaite   
        return None
    

    def can_move(self, color):
    # Vérifie si le joueur de la couleur donnée peut effectuer un mouvement légal
        for piece in self.get_all_pieces(color):
            if self.get_valid_moves(piece):
                return True
        return False

    
    def get_valid_moves(self, piece):
        moves = {}
        left = piece.col - 1
        right = piece.col + 1
        row = piece.row

        if piece.color == BLACK or piece.king:
            moves.update(self._traverse_left(row -1, max(row-3, -1), -1, piece.color, left))
            moves.update(self._traverse_right(row -1, max(row-3, -1), -1, piece.color, right))
        if piece.color == WHITE or piece.king:
            moves.update(self._traverse_left(row +1, min(row+3, ROWS), 1, piece.color, left))
            moves.update(self._traverse_right(row +1, min(row+3, ROWS), 1, piece.color, right))
    
        return moves

    def _traverse_left(self, start, stop, step, color, left, skipped=[]):
        moves = {}
        last = []
        for r in range(start, stop, step):
            if left < 0:
                break
            
            current = self.board[r][left]
            if current == 0:
                if skipped and not last:
                    break
                elif skipped:
                    moves[(r, left)] = last + skipped
                else:
                    moves[(r, left)] = last
                
                if last:
                    if step == -1:
                        row = max(r-3, 0)
                    else:
                        row = min(r+3, ROWS)
                    moves.update(self._traverse_left(r+step, row, step, color, left-1,skipped=last))
                    moves.update(self._traverse_right(r+step, row, step, color, left+1,skipped=last))
                break
            elif current.color == color:
                break
            else:
                last = [current]

            left -= 1
        
        return moves

    def _traverse_right(self, start, stop, step, color, right, skipped=[]):
        moves = {}
        last = []
        for r in range(start, stop, step):
            if right >= COLS:
                break
            
            current = self.board[r][right]
            if current == 0:
                if skipped and not last:
                    break
                elif skipped:
                    moves[(r,right)] = last + skipped
                else:
                    moves[(r, right)] = last
                
                if last:
                    if step == -1:
                        row = max(r-3, 0)
                    else:
                        row = min(r+3, ROWS)
                    moves.update(self._traverse_left(r+step, row, step, color, right-1,skipped=last))
                    moves.update(self._traverse_right(r+step, row, step, color, right+1,skipped=last))
                break
            elif current.color == color:
                break
            else:
                last = [current]

            right += 1
        
        return moves
    
    def clone(self):
        new_board = Board()
        new_board.BLACK_left = self.BLACK_left
        new_board.white_left = self.white_left
        new_board.BLACK_kings = self.BLACK_kings
        new_board.white_kings = self.white_kings
        new_board.last_move = self.last_move  # Adjust if needed
        # Copy the board matrix (assuming it's a 2D list)
        new_board.board = [row[:] for row in self.board]
        return new_board
    
    def get_last_applied_move(self):
        return self.last_move
    
    def mcts_move(self, piece, row, col):
        if piece == 0:
            # Handle the case where piece is 0 (not an instance of the Piece class)
            # You might want to log a message or take appropriate action.
            pass
        else:
            initial_row, initial_col = piece.row, piece.col
            self.last_move = (initial_row, initial_col, row, col)
            self.board[initial_row][initial_col], self.board[row][col] = self.board[row][col], self.board[initial_row][initial_col]
            piece.move(row, col)

            if row == ROWS - 1 or row == 0:
                if not piece.is_king():
                    piece.make_king()
                    if piece.color == WHITE:
                        self.white_kings += 1
                    else:
                        self.BLACK_kings += 1